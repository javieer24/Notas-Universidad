# Título 1
## Título 2
### Título 3
#### Título 4
##### Título 5
###### Título 6

# Cita
>Solo sé que no sé nada
>\- Sócrates

# Lista de compras
- Tomate
- Lechuga
+ Zanahoria
+ Sandia
* Manzana
* Pan

# Colores
1. Primarios
   - Rojo
   - Amarillo
   - Azul
2. Secundarios
   + Naranja
   + Verde
   + Morado

# Separación o división
Son 3 guiones bajos
___

# Negritas y cursivas
*Texto con cursiva*
**Texto en negrita**
***Texto en cursiva y negrita***

# Enlaces
[Buscar](www.google.com "Google")

www.google.com


# Imágenes
![Gato](https://www.nolodejesalazar.es/wp-content/uploads/sites/26/2021/03/GettyImages-1144717811-e1582815778452.jpg?w=700)

# Código
    Este es un código (son 4 espacios)

~~~
Este es código :u
~~~


# Anular Markdown
No lo sé Rick, \*parece falso*