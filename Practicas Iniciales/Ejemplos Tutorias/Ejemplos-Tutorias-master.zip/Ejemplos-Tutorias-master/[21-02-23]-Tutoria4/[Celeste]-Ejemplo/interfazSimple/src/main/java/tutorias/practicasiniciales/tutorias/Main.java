package tutorias.practicasiniciales.tutorias;


public class Main {

   
    public static void main(String[] args) {
        Vista app = new Vista();
        app.setVisible(true);
        app.setLocationRelativeTo(null); 
    }
    
}
