print("Hola, ¿cuál es tu nombre?")
nombre = input()
print("Gusto en conocerte, " , nombre) 

apellido = input("¿Cuál es tu apellido?\n")
print("Entonces tu nombre completo es: " , nombre, apellido, " :)") 