/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package tutorias.practicasiniciales.ejemploclase5;

import diseño.Vista;

/**
 *
 * @author Celeste Rodas
 */
public class Main {

    public static void main(String[] args) {
      Vista vista = new Vista(); 
      vista.setVisible(true);
      vista.setLocationRelativeTo(null);
      vista.setResizable(false);
      vista.setSize(1300, 700);
    }
    
}
