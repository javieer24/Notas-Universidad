# TALLER 2

En Este taller se dio una introduccion a lo que es programacion orientada objetos y la implementacion de este paradigma a codigo

>link de la grabacion: https://drive.google.com/file/d/1qL_X0ZLJh1Jc-PF0XOEpOJVfxRKvPIpm/view?usp=share_link
