# PRIMER TALLER

En este taller se llevo a cabo la realizacion de un ejercicio, utilizando condicionales, bucles y funciones


>Link de la grabacion:  https://drive.google.com/file/d/1q8LbilsUhJTdgv0yWBe5Mm4vynNfjE3D/view?usp=share_link

