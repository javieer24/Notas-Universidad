
*Universidad San Carlos de Guatemala*

*Facultad de Ingeniería*

*Escuela de Ciencias y Sistemas*

*Lenguajes Formales y de Programación*

*Laboratorio Lenguajes Formales y de Programación*

*Auxiliar: DIEGO ANDRÉS OBÍN ROSALES*

    EJEMPLOS DE LABORATORIO
  
```python
print("Bienvenidos al laboratorio del Curso Lenguajes Formales y de Programacion")

actitud = true
while(actitud):
    print("Yo puedo, yo confio en mi")
```