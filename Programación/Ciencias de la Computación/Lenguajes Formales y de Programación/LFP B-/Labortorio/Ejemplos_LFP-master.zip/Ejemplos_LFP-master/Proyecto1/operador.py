from enum import Enum

class Operador(Enum):
    OPERACION = 0
    SUMA = 1
    RESTA = 2
    MULTIPLICACION = 3
    DIVISION = 4
    POTENCIA = 5
    MODULO = 6
    INVERSO = 7
    TANGENTE = 8
    COSENO = 9
    SENO = 10
    RAIZ = 11
    