from ListaSimple import ListaSimple

ls = ListaSimple()

ls.agregarFinal(5)
ls.agregarFinal(6)
ls.agregarFinal(7)
ls.agregarFinal(8)

ls.imprimir()
ls.graficar()