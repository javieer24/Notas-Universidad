# IPC2 N
## 2do. Semestre 2023

semana6