class NodoBase():
    def __init__(self):
        self.indice = 0

    def getIndice(self):
        return self.indice
    
    def setIndice(self, indice):
        self.indice = indice
    