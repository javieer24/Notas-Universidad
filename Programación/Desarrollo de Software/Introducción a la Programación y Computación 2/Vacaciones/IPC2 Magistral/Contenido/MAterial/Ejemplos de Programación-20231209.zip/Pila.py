#Pilas 

pila = [1,2,3]

#Agregar datos a la pila
pila.append(4)
pila.append(5)

#Sacando elementos
n=pila.pop()

print(f"sacando el elemento  {n}")

#mostrar Pila
print(pila)