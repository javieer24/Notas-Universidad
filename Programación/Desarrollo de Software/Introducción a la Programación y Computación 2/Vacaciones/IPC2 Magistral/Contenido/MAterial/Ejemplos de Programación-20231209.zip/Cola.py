#Colas


cola=["Alumno1","Alumno2","Alumno3","Alumno4"]

#Agregar alumno a la cola
cola.append("Alumno5")
cola.append("Alumno6")

#Sacar elmento de la cola
n=cola.pop(0)
print(f"atendiento a {n}")

n=cola.pop(0)
print(f"atendiento a {n}")