using byte = unsigned char;

class Nodo {
public:
  int info;
  int i, j;
  Nodo *izq, *der, *abajo, *arriba;
};

class MatrizOrtogonal {
public:
  MatrizOrtogonal(int f, int c) {
    filas = new Nodo *[f];
    cols = new Nodo *[c];
  }
  
  void insert(int info, int i, int j) {
    Nodo* nuevo = new Nodo();
    nuevo->info = info;
    nuevo->i = i;
    nuevo->j = j;
    reemplazar(nuevo, i, j);
    enlazarColumna(nuevo);
  }

  void move(byte F1, byte C1, byte F2, byte C2, byte FD, byte CD) {
    if (F1 > F2 || C1 > C2 || FD <= F2 || CD <= C2) {
      throw "Coordenadas Invalidas";
    }
    
    Nodo *start = buscar(F1, C1);
    Nodo *end = buscar(F2, C2);

    if(start == nullptr || end == nullptr) return;

    while (start != nullptr && start->j <= end->j) { 
      Nodo* next = start->der; 

      reemplazar(start, start->i + FD - F1, start->j + CD - C1); 
      enlazarColumna(start); 
      
      start = next; 
    }
  }

private:
  Nodo *filas[]; // 1..256
  Nodo *cols[];  // ..256
  
  Nodo *buscar(int x, int y) {
    Nodo *recorre = filas[x];
    while (recorre != nullptr && recorre->j < y) {
      recorre = recorre->der;
    }
    return (recorre != nullptr && recorre->j == y) ? recorre : nullptr;
  }
  
  void reemplazar(Nodo* origen, int x, int y) {
    Nodo* recorre = filas[x];
    Nodo* antFila = nullptr;

    while (recorre != nullptr && recorre->j < y) {
      antFila = recorre;
      recorre = recorre->der;
    }

    if (recorre != nullptr && recorre->j == y) {
      eliminarNodo(recorre, x, y);
      antFila = recorre->izq;
    }

    if (origen != nullptr) {
      insertarNodo(origen, antFila, x, y);
    }
  }

  void eliminarNodo(Nodo* nodo, int x, int y) {
    if (nodo->izq == nullptr) {
      filas[x] = nodo->der;
    } else {
      nodo->izq->der = nodo->der;
    }
    if (nodo->der != nullptr) {
      nodo->der->izq = nodo->izq;
    }
    if (nodo->arriba == nullptr) {
      cols[y] = nodo->abajo;
    } else {
      nodo->arriba->abajo = nodo->abajo;
    }
    if (nodo->abajo != nullptr) {
      nodo->abajo->arriba = nodo->arriba;
    }
    delete nodo;
  }

  void insertarNodo(Nodo* nodo, Nodo* antFila, int x, int y) {
    nodo->izq = antFila;
    if (antFila != nullptr) {
      nodo->der = antFila->der;
      antFila->der = nodo;
    }
    if (nodo->der != nullptr) {
      nodo->der->izq = nodo;
    }
  }

  void enlazarColumna(Nodo* nodo) { 
    if(nodo == nullptr) return;

    int x = nodo->i;
    int y = nodo->j;

    Nodo* above = buscar(x - 1,y);
    Nodo* below = buscar(x + 1,y);

    nodo->arriba = above;
    nodo->abajo = below;

    if(above != nullptr)
        above ->abajo= nodo;
   
    if(below != nullptr)
        below ->arriba= nodo;
  }
};
