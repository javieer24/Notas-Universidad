if (llueve || haySol) {
  irAlCine();
} else {
  verTv();
}
