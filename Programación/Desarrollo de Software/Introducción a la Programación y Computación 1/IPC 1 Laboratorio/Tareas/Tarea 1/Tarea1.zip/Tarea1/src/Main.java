public class Main {
    public static void main(String[] args) {
        //Creamos una variable de tipo entero y le damos un valor
        int miNumero = 5;
        //LLamamos a una función que modifica el valor de la variable
        modificarNumero(miNumero);
        //Imprimimos el valor de la variable
        System.out.println(miNumero);

    }

    private static void modificarNumero(int miNumero) {
        //Modificamos el valor de la variable a 7
        miNumero = 7;
        System.out.println(miNumero);
    }

}




